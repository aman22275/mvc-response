<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Title</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
	<script src="<?php echo base_url('assets/js/jquery.js')?>"></script>
	<script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
	
</head>
<body class="wrap">

<div class="container">
	<div class="" >
			<div class="ppage">
				<label> Add New Email:</label>
				<button type="button" class="btn bg-info" data-toggle="modal" data-target=".bs-example-modal-sm">+</button>
			</div>			
				<div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  					<div class="modal-dialog modal-sm">
    					<div class="modal-content">
    						<form action="<?php echo site_url('rander/rand'); ?>" method="POST" id="form">
								<label for="email">Email:</label>
								<input type="email" name="email" id="email">
								<input type="submit" value="submit">
							</form>
      					
    					</div>
  					</div>
				</div>
		<div class="tdata">
			<table border="1" class="tdata">

				<tr><th class="tab">Id</th> <th class="tab">Email</th> <th class="tab">Code</th><th class="tab">Action</th></tr>

					<?php foreach($profile as $key=>$value): ?>

				<tr class="tab"> 
					<td class="tab">
						<?php echo $value['id']; ?>
					</td> 
					<td class="tab">
						<?php  echo $value['email']; ?>
					</td>
					<td class="tab">
						<?php  echo $value['code']; 


						?>
					</td>
					<td class="tab">
						<a href="<?php echo site_url('insert/generate?action='.$value['id']); ?>">
							<?php 
							if( strlen($value['code']) < 2 ){
								echo '<input type=button value=Generate';
								}else{
										echo '<input type=button value=Regenerate';
									}

	 						?>

						</a>
					</td>
				</tr>

					<?php endforeach; ?>		 
			</table>
		</div>
	
		<p class="lpage">
			<a href=" <?php echo site_url('user/logout'); ?> ">
				<input type="button" value="logout"/>
			</a>
		</p>
	</div>
</div>
<script type="text/javascript">
	
	$(document).on('submit','#form',function(e){
  	e.preventDefault();
  //alert('ram');
//prepare request

 var formData = $('#form').serialize();
 var method = $('#form').attr('method');
 var url = $('#form').attr('action');


$.ajax({
  url : url,
  type : method,
  data : formData
}).success(function(response){
    var response = JSON.parse(response);
    if(response.status){
      //login
      window.location.href = response.message;
    }else{
    	//fail
    	document.write(response.message);
    }

});

 console.log(formData);

  });


</script>
</body>
</html>