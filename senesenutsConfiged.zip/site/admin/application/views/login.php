<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Title</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css')?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
	<script src="<?php echo base_url('assets/js/jquery.js')?>"></script>
</head>
<body class="wrap">
	<div class="container">
		<div class="row tdata" >
			<?php if($this->session->flashdata('message')): ?>

			<h3>
				<?php echo $this->session->flashdata('message'); ?>
			</h3>

			<?php endif; ?>

			<form action="<?php echo site_url('user/login'); ?>" method = "POST" id="form">
				<label for="email">User Name:</label>
				<input type="text" name="email" id="email">
				<p class="lpage"><label for="pass">Password:</label>
				<input type="password" name="password" id="pass"></p>
				<input type="submit" value="submit">
			</form>
		</div>
	</div>
	<script type="text/javascript">
	
	$(document).on('submit','#form',function(e){
  	e.preventDefault();
  //alert('ram');
//prepare request

 var formData = $('#form').serialize();
 var method = $('#form').attr('method');
 var url = $('#form').attr('action');
 
$.ajax({
  url : url,
  type : method,
  data : formData
}).success(function(response){
    var response = JSON.parse(response);
    if(response.status){
      //login
      window.location.href = response.message;
    }else{
    	//fail
    	alert(response.message);
    }

});

 console.log(formData);

  });


</script>
</body>
</html>