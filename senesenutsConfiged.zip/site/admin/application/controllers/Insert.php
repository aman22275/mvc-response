<?php

class Insert extends CI_Controller{

function __construct(){
	parent::__construct();
	$this->load->model('usermodel');

	if( !$this->session->userdata('id') ){
		//not logged in, show login page
			redirect( site_url('user/login') );
	}

}

public function index(){


	redirect(site_url());
}
function generate(){

$data = $this->input->get('action');
$gn = $this->usermodel->generate($data);

if($gn){
	redirect( site_url('profile') );
}

}
}