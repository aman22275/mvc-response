<?php

class Profile extends CI_Controller{

function __construct(){
	parent::__construct();
	$this->load->model('usermodel');

	if( !$this->session->userdata('id') ){
		//not logged in, show login page
			redirect( site_url('user/login') );
	}

}

function index(){

	//$id = $this->session->userdata('id');

	$userdata =	$this->usermodel->profile();

	$data['profile'] = $userdata;

	$this->load->view('profile' , $data);
}

}