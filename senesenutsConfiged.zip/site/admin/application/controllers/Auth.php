<?php

class Auth extends CI_Controller{

public function index(){


	//l'll check your state on the site

	if( !$this->session->userdata('id') ){
		//not logged in, show login page
			redirect( site_url('user/login') );
	}else{
		//logged in, show profile page
		redirect( site_url('profile') );
	}


}


}