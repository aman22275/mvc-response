<?php

class Rander extends CI_Controller{

function __construct(){
	parent::__construct();
	$this->load->model('usermodel');

	if( !$this->session->userdata('id') ){
		//not logged in, show login page
			redirect( site_url('user/login') );
	}

}

public function index(){


	redirect(site_url());
}
function rand(){

	

	$data = $this->input->post();

	//print_r($data);

if($data){
		//means user if trying to log in

		$response = $this->usermodel->rander($data);

		if($response){
			//do login
			echo json_encode(
					array(
						'status' => true,
						'message' => site_url('profile')
						)

				);

		}else{
			//do NOT login
			//$value['msg'] = 'You are Enter Wrong Email';
			echo json_encode(
					array(
						'status' => false,
						'message' => 'Wrong'
						)

				);

			//$this->load->view('email',$value);

		}

		return TRUE;
}

redirect(site_url());
}
}