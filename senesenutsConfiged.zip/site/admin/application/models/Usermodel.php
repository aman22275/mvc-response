<?php

class Usermodel extends CI_Model{

function __construct(){
	parent::__construct();
}

function login($data){


	$email= $data['email'];
	$password = $data['password'];

	if( ($email === 'admin@sensenuts.com') && ($password === 'sensenuts') ){
return true;
	}else{
		return FALSE;
	}

}

function profile(){
	
	
	$que = $this->db->get('user_data');
	return $que->result_array();

}

function rander($data){

	$email = $data['email'];

$ins = array(
		'email' => $email
		);
$this->db->where('email' , $email);

$que = $this->db->get('user_data');		
		
		if($que->num_rows() > 0){

			
		return FALSE;
			
	}
	else{

		$this->db->insert('user_data' , $ins);
		return TRUE;
	}


}


public function generate($data){

	$id = $data;
	$nul='';

	$this->db->where('id', $id);
	//$this->db->where('code' , $nul);

	$que = $this->db->get('user_data');

	$ins = array(
		'code' => strtolower( random_string('alnum', 10) )
		);

	$this->db->where('id', $id);
	$this->db->update('user_data',$ins);

	//echo 'inserted';
	return TRUE;

}

}
