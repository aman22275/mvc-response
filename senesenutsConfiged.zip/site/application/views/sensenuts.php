<!DOCTYPE html>
<!--[if lt IE 7 ]><html style="margin-top: 0 !important" class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html style="margin-top: 0 !important" class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html style="margin-top: 0 !important" class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <!--<![endif]-->
<html style="margin-top: 0 !important" lang="en-US"> <!--<![endif]-->
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Sensenuts</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Josefin+Slab:600' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,300italic' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url('resources/assets/css/bootstrap.min.css')?>" type="text/css" media="all" >
	
	<link rel="stylesheet" href="<?php echo base_url('resources/css/bootstrap-theme.css')?>" type="text/css" media="all" >
	<link rel="stylesheet" href="<?php echo base_url('resources/assets/css/style.css')?>" type="text/css" media="all" >
	<link rel="stylesheet" href="<?php echo base_url('resources/assets/css/responsive.css')?>" type="text/css" media="all" >
	<link rel="stylesheet" href="<?php echo base_url('resources/assets/css/simpletextrotator.css')?>" type="text/css" media="all" >
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400,300,600' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('resources/css/jquery.mCustomScrollbar.css')?>" />
	<link href="<?php echo base_url('resources/css/styles.css')?>" type="text/css" rel="stylesheet"  />
	<link href="<?php echo base_url('resources/css/lightbox.css')?>" rel="stylesheet" />
	<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
	<script src="<?php echo base_url('resources/assets/js/jquery.js')?>"></script>
	<script src="<?php echo base_url('resources/assets/karacas-imgLiquid-8cb2bfd/js/imgLiquid-min.js')?>"></script>
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
	
	
</head>
<body data-spy="scroll" data-target=".navbar">
	<div class="se-pre-con"></div>
	<script>
		$(window).load(function() {
			// Animate loader off screen
		
			$(".se-pre-con").fadeOut("slow");
		});
	</script>
	<!-- Canvas Starts -->
	<div class="body-can">
		<div class="canvas_text ">
			<span class="rotate center-text">Sensing, Scalability, Robust, Intelligence, Internet of Things, Connectivity</span>
			<h2 id="center-head">SENSEnuts</h2>
			<span class="center-text rotate">WSN sensation,IoT sensation</span>
			
		</div>
	</div>
	<canvas></canvas>
	<!-- Canvas Ends -->
	<nav id="bt-menu" class="bt-menu">
		<a class="bt-menu-trigger" href="javascript:void(0);">
			<span>Menu</span>
		</a>
	</nav>
	<header id="header">
		<div class="header-holder">
			<div class="container menu-margin-top hidden-phone  " >
				
				<div class="brow">
					<ul id="rb-grid" class="rb-grid clearfix">
						<li>
							<div class="brick1 brick1-margin-responsive width-margin-feeds offset7 brick1-margin-responsive-product">
								
							</div>
						</li>
						<li id="product">
							
							
							<div class="brick1 odd forum-margin ">
								
								<a href="javascript:void(0);" id="forum-newtab"class="nav-item">
									<div class="nav-hover"></div>
									<i class="fa fa-users"></i>
									<span>Forum</span>
								</a>
							</div>
							<!-- <div class="rb-overlay"  >
									<span class="rb-close"><a href="javascript:void(0);"></a></span>
									<div class="rb-week">
											<div class="container" id="containerI">
													<div class="main" id="about">
															
															<h1>Forum</h1>
															<div class="container-fluid">
																add statement of forum
																	
															</div>
													</div>
													<div class="container_bottom"></div>
											</div>
									</div>
								
								
							</div> -->
							<script type="text/javascript">
							$(document).ready(function(){
							$("#forum-newtab").on('click',function(){
							window.open('http://sensenuts.com/forum', '_blank');
								
							});
							});
							</script>
						</li>
						<script type="text/javascript">
						var value=0;
						
							
						$.fn.swapWith = function(swap_with_selector) {
						var el1 = this;
						var el2 = $(swap_with_selector);
						
						if ( el1.length === 0 || el2.length === 0 )
						return;
						
						var el2_content = el2.html();
						el2.html(el1.html());
						el1.html(el2_content);
						};
						function remove() {
						
						if(value==1){
						
							$('#logo').swapWith('#product');
							$('.third-row-logo-margin').css({'margin-left': '0px'});
						$('.forum-margin').css({'margin-left':'0px'});
						}
						else
						{
						$('.third-row-logo-margin').css({'margin-left': '0px'});
						$('.forum-margin').css({'margin-left':'0px'});
						}
						
						}
						
						
						function logo() {
							value=1;
								
							$('#logo').swapWith('#product');
							$('.third-row-logo-margin').css({'margin-left': '64px'});
						$('.forum-margin').css({'margin-left':'134px','margin-top':'-120px'});
						}
						
						
						var bounds = [
						{min:300,max:600,func:logo},
						
						{min:601,max:1024,func:remove}
						];
						
						// define a resize function. use a closure for the lastBoundry determined.
						var resizeFn = function(){
						var lastBoundry; // cache the last boundry used
						return function(){
						var width = window.innerWidth; // get the window's inner width
						var boundry, min, max;
						for(var i=0; i<bounds.length; i++){
						boundry = bounds[i];
						min = boundry.min || Number.MIN_VALUE;
						max = boundry.max || Number.MAX_VALUE;
						if(width > min && width < max
						&& lastBoundry !== boundry){
						lastBoundry = boundry;
						return boundry.func.call(boundry);
						}
						}
						}
						};
						$(window).resize(resizeFn()); // bind the resize event handler
						$(document).ready(function(){
						$(window).trigger('resize'); // on load, init the lastBoundry
						});
						</script>
						
					</ul>
				</div>
				<div class="brow">
					<ul id="rb-grid" class="rb-grid clearfix ">
						
						<li>
							<div class="brick1 brick1-margin-responsive width-margin-feeds offset7   ">
								
							</div>
						</li>
						<li>
							<div class="brick1  odd package-margin ">
								<a href="javascript:void(0);" class="nav-item">
									<div class="nav-hover"></div>
									<i class="fa fa-cloud-download"></i>
									<span>Downloads</span>
								</a>
							</div>
							<div class="rb-overlay" >
								<span class="rb-close"><a href="javascript:void(0);"></a></span>
								<div class="rb-week">
									<div class="container" id="containerI">
										<div class="main" id="about">
											
											
											<h1> DOWNLOADS</h1>
											<div class="container-fluid">
												
												<div>
													<div class="row">
														<div class="col-lg-6 col-sm-12"id="text_justify">
															<p>
																This place for text
															</p>
															<p>
																
																Find Google Maps coordinates - fast and easy!
																default
																Use this tool to find and display the Google Maps coordinates (longitude and latitude) of any place in the world.
																Type an address in the search field below the map.
																Zoom in to get a more detailed view.
																Move the marker to the exact position.
																The pop-up window now contains the coordinates for the place.
																Just copy the values for longitude and latitude.
																Do you like this site? Please spread the word in Twitter.
															</p>
														</div>
														<div class="col-lg-6 col-sm-12">
															<div id="bform">
																
																<?php if(!$this->session->userdata('id')): ?>
																
																<div id="bform">
																	<form id="aform" action="POST" >
																		<div class="form-group ">
																			<label for="exampleInputName1">Your Email ID</label>
																			<input type="text" class="form-control" name="email" placeholder="Email">
																		</div>
																		<div class="form-group">
																			<label for="exampleInputpassword">Your Password</label>
																			<input type="password" class="form-control" name="password" placeholder="password">
																		</div>
																		
																		<div>
																			<p class="captcha">5+6=</p>
																			<input type="text" class="form-control captcha" id="captchaInput" placeholder="captcha">
																			<button class="btn-quote" id="submit_form">Login</button>
																			
																		</div>
																		
																	</form>
																</div>
																
																<?php else: ?>
																<div class="senlog">
																	<a onClick = "window.location.href ='<?php echo site_url('user/logout'); ?>'">
																		<button class="btn-quote">Logout</button>
																	</a>
																	</div><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus laboriosam alias blanditiis voluptate ratione autem adipisci, assumenda repudiandae dolorem neque fugiat sed quisquam vero aut aperiam suscipit, quo qui praesentium.</p>
																	<a onClick = "window.location.href ='http://sensenuts.com/resources/img/Universal-USB-Installer-1.9.5.9.exe'">
																	<button class="btn-quote">Download</button></a>
																	<?php endif; ?>
																</div>
																<div id="willload">
																	
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<script>
											
											$('#submit_form').click(function(e){
											e.preventDefault();
											//prepare data
											var frmdata = $('#aform').serialize();
												
												$.ajax({
													url : 'http://sensenuts.com/index.php/user/login',
													type : 'POST',
													data  : frmdata
												}).success(function(response){
													
														//alert(response);
												var response = JSON.parse(response);
													if(response.status)
													{
														$('#willload').html('<div class="senlog"><a onClick = "window.location.href =\'http://sensenuts.com/index.php/user/logout\'"> <button class="btn-quote">Logout</button></a></div>'+'<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Delectus laboriosam alias blanditiis voluptate ratione autem adipisci, assumenda repudiandae dolorem neque fugiat sed quisquam vero aut aperiam suscipit, quo qui praesentium.</p><a onClick = "window.location.href =\'http://sensenuts.com/resources/img/Universal-USB-Installer-1.9.5.9.exe\'"> <button class="btn-quote">Download</button></a>'
														);
														$('#bform').remove();
													}
													else
													{
														alert('Wrong email/password combination');
													}
												});
											});
											</script>
											
											<div class="container_bottom">
												
											</div>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</div>
					<div class="brow  rowHack">
						<ul id="rb-grid" class="rb-grid clearfix ">
							<li>
								<div class="brick1 odd offset1 gallery-margin ">
									<a href="javascript:void(0);" id="product-tile-technology" class="nav-item">
										<div class="nav-hover "></div>
										<i class="fa fa-sitemap "></i>
										<span >Technology</span>
									</a>
								</div>
								<div class="rb-overlay"  >
									<span class="rb-close"><a href="javascript:void(0);"></a></span>
									<div class="rb-week">
										<div class="container" id="containerI">
											<div class="main" id="about">
												
												<h1>Technologies</h1>
												<h4>Our products are based on the following technologies.</h4>
												
												
												<p>1. Internet of Things (IOT)</p>
												
												
												<p>2. IEEE 802.15.4 </p>
												
												
												<p>3. Embedded system </p>
												
												<div class="container-fluid prod ">
													<ul class="list-inline prod-ul list-hack"  id="button_active">
														<li class="list-tab">
															<a href="#" id="first-product-technology" class="aproduct-technology btn" data-url="IOT.html">
																IoT
															</a>&nbsp;
														</li>
														<li class="list-tab">
															<a href="#" class="aproduct-technology btn" data-url="IEEE.html">
																IEEE 802.15.4
															</a>&nbsp;
														</li>
														<li class="list-tab">
															<a href="#" class="aproduct-technology btn" data-url="Embedded.html">
																Embedded system
															</a>&nbsp;
														</li>
														
														
													</ul>
													
													<br/>
													<div id="product-showcase-technology">
														
													</div>
													
												</div>
											</div>
											<div class="container_bottom"></div>
										</div>
									</div>
								</div>
							</li>
							<li>
								<div class="brick1  odd ">
									<a href="javascript:void(0);" id="product-tile" class="nav-item">
										<div class="nav-hover"></div>
										<i class="fa fa-wrench"></i>
										<span>Products</span>
									</a>
								</div>
								<div class="rb-overlay"  >
									<span class="rb-close"><a href="javascript:void(0);"></a></span>
									<div class="rb-week">
										<div class="container" id="containerI">
											<div class="main" id="about">
												
												<h1>Products</h1>
												<div class="container-fluid prod">
													
													<ul class="list-inline prod-ul" id="button_active_product">
														<li class="list-tab">
															<a href="#"  id="first-product" class="aproduct btn" data-url="radio.html">
																Radio
															</a>&nbsp;
														</li>
														<li class="list-tab">
															<a href="#" class="aproduct btn" data-url="gateway.html">
																Gateway
															</a>&nbsp;
														</li>
														<li class="list-tab">
															<a href="#" class="aproduct btn" data-url="sensor.html">
																Sensors
															</a>&nbsp;
														</li>
														<li class="list-tab">
															<a href="#" class="aproduct btn" data-url="battery.html">
																Battery
															</a>&nbsp;
															<li class="list-tab">
																<a href="#" class="aproduct btn" data-url="extender.html">
																	Extender
																</a>&nbsp;
															</li>
															
														</ul>
														
														<br/>
														<div id="product-showcase">
															
														</div>
													</div>
												</div>
												<div class="container_bottom"></div>
											</div>
										</div>
										
									</div>
								</li>
								
								<li>
									<div class=" odd brick1 download-margin">
										<a href="javascript:void(0);" class="nav-item">
											<div class="nav-hover"></div>
											<i class="fa fa-gift"></i>
											<span>Packages</span>
										</a>
									</div>
									<div class="rb-overlay"  >
										<span class="rb-close"><a href="javascript:void(0);"></a></span>
										<div class="rb-week">
											<div class="container" id="containerI">
												<div class="main" id="about">
													
													<h1>Packages</h1>
													<div class="container-fluid">
														<p>Various configuration of the modules are available for the users on the basis of research and applications.<b> ProLAB</b> and <b>TeachLAB</b> are standard packages available for class room teaching and Lab purpose. <b>DemoLAB</b> is available for the scholars for research purpose. The configuration of each packages are as below</p>
														
														<table class="al-table">
															<tr>
																<td>
																	
																</td>
																<td>
																	<b>ProLab</b>
																</td>
																<td>
																	<b>TeachLab</b>
																</td>
																<td>
																	<b>DemoLab</b>
																</td>
															</tr>
															<tr>
																<td>
																	<b>Radios</b>
																</td>
																<td>
																	30
																</td>
																<td>
																	15
																</td>
																<td>
																	06
																</td>
															</tr>
															<tr>
																<td>
																	<b>Gateways</b>
																</td>
																<td>
																	20
																</td>
																<td>
																	10
																</td>
																<td>
																	04
																</td>
															</tr>
															<tr>
																<td>
																	<b>Sensor-STL</b>
																</td>
																<td>
																	10
																</td>
																<td>
																	05
																</td>
																<td>
																	02
																</td>
															</tr>
															<tr>
																<td>
																	<b>Extender</b>
																</td>
																<td>
																	02
																</td>
																<td>
																	01
																</td>
																<td>
																	Optional
																</td>
															</tr>
															<tr>
																<td>
																	<b>Sensor-GAP</b>
																</td>
																<td>
																	Optional
																</td>
																<td>
																	Optional
																</td>
																<td>
																	Optional
																</td>
															</tr>
															<tr>
																<td>
																	<b>Sensor-HTP</b>
																</td>
																<td>
																	Optional
																</td>
																<td>
																	Optional
																</td>
																<td>
																	Optional
																</td>
															</tr>
														</table>
														<p>
															We also provided customized configuration for the users.
														</p>
													</div>
												</div>
												<div class="container_bottom"></div>
											</div>
										</div>
										
										
									</div>
								</li>
								<li>
									<div class="brick1 width-feeds  third-row-margin odd">
										<a href="javascript:void(0);" class="nav-item">
											<div class="nav-hover"></div>
											
											<marquee SCROLLAMOUNT="3" direction="up" height="88%" width="95%" class="margin-feed1">
											
											<p class="fon">1. Eigen announces a new sensor module with GPS, PIR and Accelerometer sensor in SENSEnuts kitty, to bolster new applications in the area of location awareness, motion sensing & security.</p>
											<p class="fon">2. Mr. Rajeshwar Singh, Implementation Head, Eigen Technologies Delhi, delivered a talk on WSN technologies at Galgotia University, Greater Noida where he showcased the strength of SENSEnuts platform and how it may help faculties and researchers to develop new IoT applications. <a href="http://galgotiasuniversity.edu.in/pdf/Report_on_workshop.pdf">link</a></p>
											<p class="fon">3. Mr. Ankur Tyagi, Tech Lead, Eigen Technologies, delivered a technical session at NITTTR, Chandigarh, giving in-depth view of WSN standards & technologies and showing the power & capabilities of newly launched platform SENSEnuts for WSN research and development. <a href="https://www.youtube.com/watch?v=XOAfr0_pW1U">link</a></p>
											<p class="fon">4. Eigen announces its new open and affordable WSN research platform SENSEnuts for developing IoT applications.
											</p>
											
											</marquee>
											
											<!-- <i class="fa fa-list-ul"></i>
											<span>Feeds</span> -->
										</a>
									</div>
									<div class="rb-overlay"  >
										<span class="rb-close"><a href="javascript:void(0);"></a></span>
										<div class="rb-week">
											<div class="container" id="containerI">
												<div class="main" id="about">
													
													<h1>Feeds</h1>
													<div class="container-fluid">
														<div class="row">
															<div class="col-lg-12">
																<p>1) Eigen announces a new sensor module with GPS, PIR and Accelerometer sensor in SENSEnuts kitty, to bolster new applications in the area of location awareness, motion sensing & security.</p>
																<p>2) Mr. Rajeshwar Singh, Implementation Head, Eigen Technologies Delhi, delivered a talk on WSN technologies at Galgotia University, Greater Noida where he showcased the strength of SENSEnuts platform and how it may help faculties and researchers to develop new IoT applications. <a href="http://galgotiasuniversity.edu.in/pdf/Report_on_workshop.pdf">link</a></p>
																<p>3) Mr. Ankur Tyagi, Tech Lead, Eigen Technologies, delivered a technical session at NITTTR, Chandigarh, giving in-depth view of WSN standards & technologies and showing the power & capabilities of newly launched platform SENSEnuts for WSN research and development. <a href="https://www.youtube.com/watch?v=XOAfr0_pW1U">link</a></p>
																<p>4) Eigen announces its new open and affordable WSN research platform SENSEnuts for developing IoT applications.
																</p>
																<p>5) Eigen announces a new sensor module with GPS, PIR and Accelerometer sensor in SENSEnuts kitty, to bolster new applications in the area of location awareness, motion sensing & security.</p>
																<p>6) Mr. Rajeshwar Singh, Implementation Head, Eigen Technologies Delhi, delivered a talk on WSN technologies at Galgotia University, Greater Noida where he showcased the strength of SENSEnuts platform and how it may help faculties and researchers to develop new IoT applications. <a href="http://galgotiasuniversity.edu.in/pdf/Report_on_workshop.pdf">link</a></p>
																<p>7) Mr. Ankur Tyagi, Tech Lead, Eigen Technologies, delivered a technical session at NITTTR, Chandigarh, giving in-depth view of WSN standards & technologies and showing the power & capabilities of newly launched platform SENSEnuts for WSN research and development. <a href="https://www.youtube.com/watch?v=XOAfr0_pW1U">link</a></p>
																<p>8) Eigen announces its new open and affordable WSN research platform SENSEnuts for developing IoT applications.
																</p>
															</div>
															
														</div>
													</div>
												</div>
												<div class="container_bottom"></div>
											</div>
										</div>
									</div>
								</li>
								<li>
									<div class="brick1 odd ">
										<a href="javascript:void(0);" class="nav-item">
											<div class="nav-hover"></div>
											<i class="fa fa-picture-o"></i>
											<span>Gallery</span>
										</a>
									</div>
									<div class="rb-overlay"  >
										<span class="rb-close"><a href="javascript:void(0);"></a></span>
										<div class="rb-week">
											<div class="container" id="containerI">
												<div class="main" id="about">
													
													<h1>Gallery</h1>
													<div class="container-fluid">
														<div class="row">
															<div class="col-lg-12">
																<section id="examples" class="examples-section gal-cnt">
																	<iframe
																	src="http://www.youtube.com/embed/XGSy3_Czz8k">
																	</iframe>
																	
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-3.jpg')?>" data-lightbox="example-set"data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image"  src="<?php echo base_url('resources/img/demopage/image-3.jpg')?>"alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-4.jpg')?>" data-lightbox="example-set" data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-4.jpg')?>" alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-6.jpg')?>" data-lightbox="example-set" data-title="press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-6.jpg')?>" alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-1.jpg')?>" data-lightbox="example-set" data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-1.jpg')?>"alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-2.jpg')?>" data-lightbox="example-set"data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image"  src="<?php echo base_url('resources/img/demopage/thumb-2.jpg')?>"alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-5.jpg')?>" data-lightbox="example-set" data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-5.jpg')?>" alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-7.jpg')?>" data-lightbox="example-set" data-title="press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-7.jpg')?>" alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-8.png')?>" data-lightbox="example-set" data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-8.png')?>"alt="" />
																		</div>
																	</a>
																	
																	
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-6.jpg')?>" data-lightbox="example-set" data-title="press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-6.jpg')?>" alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/image-1.jpg')?>" data-lightbox="example-set" data-title=" press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/thumb-1.jpg')?>"alt="" />
																		</div>
																	</a>
																	<a class="activate-lbox" href="<?php echo base_url('resources/img/demopage/butterfly-734654_1920.jpg')?>" data-lightbox="example-set" data-title="press the right arrow on your keyboard.">
																		<div class="imgLiquidFill imgLiquid" style="width:300px; height:200px;">
																			<img class="example-image" src="<?php echo base_url('resources/img/demopage/butterfly-734654_1920.jpg')?>" alt="" />
																		</div>
																	</a>
																	
																	
																</section>
															</div>
														</div>
													</div>
												</div>
												<script type="text/javascript">
												$(document).ready(function() {
												$(".imgLiquidFill").imgLiquid();
												});
												</script>
												<div class="container_bottom"></div>
											</div>
										</div>
										
									</div>
								</li>
								<li id="logo">
									<div class="brick1   thumb third-row-logo-margin  ">
										<div class="nav-item  flipX">
											<img class="img1" src="<?php echo base_url('resources/assets/img/3.png')?>" alt="">
											<img class="img2" src="<?php echo base_url('resources/assets/img/4.png')?>" alt="">
										</div>
									</div>
								</li>
								<li>
									<div class="brick1 odd even ">
										<a href="javascript:void(0);" class="nav-item">
											<div class="nav-hover"></div>
											<i class="fa fa-book"></i>
											<span>Career</span>
										</a>
									</div>
									<div class="rb-overlay"  >
										<span class="rb-close"><a href="javascript:void(0);"></a></span>
										<div class="rb-week">
											<div class="container" id="containerI">
												<div class="main" id="about">
													
													<h1>Career</h1>
													<div class="container-fluid">
														<p>We at Eigen are working on new ideas and continually rediscovering ourselves. If you like to face the challenges that working on a new technology/product brings, then come join us and share your brilliance with Eigen.</p>
														<p>Currently we are looking for young and enthusiastic talents for the following career options:</p>
														<!-- <ul class="tile-ul">
																				<li>Embedded Systems</li>
																				<li>Wireless Sensor networks</li>
																				<li>PCB Designing</li>
																				<li>JAVA developer</li>
														</ul> -->
														<table class="al-table">
															<tr>
																<td>
																	Domain
																</td>
																<td>
																	Qualification
																</td>
																<td>
																	Experience
																</td>
																<td>
																	Duration of work
																</td>
															</tr>
															<tr>
																<td>
																	Embedded Systems
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
															</tr>
															<tr>
																<td>
																	Wireless Sensor networks
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
															</tr>
															<tr>
																<td>
																	PCB Designing
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
															</tr>
															<tr>
																<td>
																	JAVA developer
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
																<td>
																	
																</td>
															</tr>
														</table>
													</div>
												</div>
												<div class="container_bottom"></div>
											</div>
										</div>
									</div>
								</li>
							</ul>
						</div>
						<!-- 			-->
						<div class="brow">
							<ul id="rb-grid" class="rb-grid clearfix">
								<li>
									<div class="brick1 brick1-margin-responsive  width-margin-feeds offset7">
										
									</div>
								</li>
								<li>
									<div class="brick1 odd">
										<a href="javascript:void(0);" id="contact-click" class="nav-item">
											<div class="nav-hover"></div>
											<i class="fa fa-envelope"></i>
											<span>Contact us</span>
										</a>
									</div>
									<div class="rb-overlay"  >
										<span class="rb-close" ><a href="javascript:void(0);"></a></span>
										<div class="rb-week">
											<div class="container" id="containerI">
												<div class="main" id="about">
													
													<h1>Let's Talk ?</h1>
													<div class="container-fluid">
														<div class="row">
															<div class="col-lg-6 col-sm-6 col-xs-12">
																<p>Feel free to contact us for any inquiries, if you have any questions about our work or just say hello.</p>
																<form action="<?php echo site_url('send_mail'); ?>" id="contact-form" method="POST">
																	<div class="form-group">
																		<label for="exampleInputName1">Your Name</label>
																		<input type="text"  name="name"class="form-control " id="InputName" placeholder="Name"required="true">
																	</div>
																	<div class="form-group">
																		<label for="exampleInputEmail1">Your Email</label>
																		<input type="email" name="email"class="form-control" id="InputEmail" placeholder="Email"required="true">
																	</div>
																	<div class="form-group">
																		<label for="textArea">Your Message</label>
																		<textarea class="form-control" name="msg" id="message" placeholder="Your Message" rows="5"required="true"></textarea>
																	</div>
																	<div>
																		<p class="captcha" id="fno"> <span id="cap1"> </span>+ <span id="cap2"> </span>=</p>
																		<input type="text" id="capAns" class="form-control captcha" id="captchaInput" placeholder="captcha">
																		<button class="btn-quote" id="contact-form-btn">Send</button>
																		
																	</div>
																</form>
																
																<a href="#" class="fb-icon"></a>
																<a href="#" class="twi-icon"></a>
																
																
																
															</div>
															<div class="col-lg-6 col-sm-6 col-xs-12">
																
																
																
																
																<script>
																$('#contact-click').on('click',function(){
																initialize();
																});
																var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
																var labelIndex = 0;
																function initialize() {
																var locate = { lat: 28.630427, lng: 77.090148 };
																var map = new google.maps.Map(document.getElementById('map-canvas'), {
																zoom: 12,
																center: locate
																});
																// This event listener calls addMarker() when the map is clicked.
																google.maps.event.addListener(map, 'click', function(event) {
																addMarker(event.latLng, map);
																});
																// Add a marker at the center of the map.
																addMarker(locate, map);
																}
																// Adds a marker to the map.
																function addMarker(location, map) {
																// Add the marker at the clicked location, and add the next-available label
																// from the array of alphabetical characters.
																var marker = new google.maps.Marker({
																position: location,
																label: labels[labelIndex++ % labels.length],
																map: map
																});
																}
																/*google.maps.event.addDomListener(window, 'load', initialize);*/
																
																</script>
																<div id="map-canvas"></div>
																<h3>EIGEN Technologies P. Ltd.</h3>
																<p>3rd Floor, C-27, Community Centre</p>
																<p>Janakpuri, New Delhi-110058.</p>
																<p>Ph.: +91-11-41643004</p>
																<p>Fax: +91-11-25594359</p>
																<p>Email: wsn@sensenuts.com</p>
																
															</div>
														</div>
													</div>
												</div>
												<div class="container_bottom"></div>
											</div>
										</div>
									</div>
								</li>
								
								<!-- <li>
														<div class="brick1">
																				<a href="javascript:void(0);" class="nav-item">
																										<div class="nav-hover"></div>
																										<i class="li_bulb"></i>
																										<span>Technology</span>
																				</a>
														</div>
														<div class="rb-overlay"  >
																				<span class="rb-close"><a href="javascript:void(0);"></a></span>
																		<div class="rb-week">
																							<div class="container" id="containerI">
																																<div class="main" id="about">
																																						
																																						<h1>Page Heading</h1>
																																						<div class="container-fluid">
																																												
																																						</div>
																																</div>
																												<div class="container_bottom"></div>
																							</div>
																		</div>
													</div>
								</li> -->
								<!--
								<label for="exampleInputName1">Your Name</label>
								<input type="text" class="form-control" id="exampleInputName1" placeholder="Your Name">
							</div>
							<div class="form-group">
								<label for="exampleInputName2">Company Name</label>
								<input type="text" class="form-control" id="exampleInputName2" placeholder="Company Name">
							</div>
							<div class="form-group">
								<label for="exampleInputEmail1">Your Email</label>
								<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Your Email">
							</div>
							<div class="form-group">
								<label for="exampleInputName3">Licence Code</label>
								<input type="text" class="form-control" id="exampleInputName3" placeholder="Licence Code">
							</div>
							<button class="btn-quote">Register</button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="container_bottom"></div>
	</div>
</div>
</div>
</li> -->
<!--
<li>
			<div class="brick1">
						<a href="javascript:void(0);" class="nav-item">
										<div class="nav-hover"></div>
										<i class="li_bulb"></i>
										<span>Technology</span>
						</a>
			</div>
			<div class="rb-overlay"  >
						<span class="rb-close"><a href="javascript:void(0);"></a></span>
				<div class="rb-week">
							<div class="container" id="containerI">
																<div class="main" id="about">
																						
																						<h1>Page Heading</h1>
																						<div class="container-fluid">
																												
																						</div>
																</div>
												<div class="container_bottom"></div>
							</div>
				</div>
		</div>
</li> -->
</ul>
</div>
</div>
</header> <!-- End header -->
<script type="text/javascript" src="<?php echo base_url('resources/js/modernizr.custom.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/jquery.debouncedresize.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/jquery.mCustomScrollbar.min.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('resources/js/custom.js')?>"></script>
<script src="<?php echo base_url('resources/assets/js/classie.js')?>"></script>
<script src="<?php echo base_url('resources/assets/js/main.js')?>"></script>
<script src="<?php echo base_url('resources/assets/js/script.js')?>"></script>
<script src="<?php echo base_url('resources/assets/js/jquery.simple-text-rotator.min.js')?>"></script>
<script>
$(document).on('ready',function(){
$(".rotate").textrotator({
animation: "flip",
separator: ",",
speed: 2000
});
});
</script>
<script src="<?php echo base_url('resources/js/lightbox.js')?>"></script>
</body>
</html>
