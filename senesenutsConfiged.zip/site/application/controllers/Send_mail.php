<?php

class send_mail extends CI_Controller{

function __construct(){
	parent::__construct();

}

function index(){
$data = $this->input->post();


$name = $data['name'];
$email= $data['email'];
$msg= $data['msg'];

           /* $randompassword = $this->generateRandomString();*/
          $mailto = "contactus@eigen.in";
            $mailfrom = 'noreply@sensenuts.com';
            $email_from = 'Sensenuts Mail System(noreply@sensenuts.com)';
            $email_subject = "Contact";

$headers  = "Content-Type: text/html; charset=ISO-8859-1\r\n";
$headers .= "From: ".$mailfrom."\r\n";  
$headers .= "Reply-To: ".$email."\r\n";  
$headers .=     'X-Mailer: PHP/';
$headers .= "MIME-Version: 1.0\r\n";

            //$confirm_token_url = $this->config->item('conbaseurl').'users/confirm?confirm_id='.$confirm_token;
            $email_body = "<html>
            <body>
            <div>
            
             <p>
             <p>From :  $email<br/></p>
             <p>Message :  <br/>
             $msg </p>
             </div>
             </body>       
      </html>";
           
//echo $email_body;
/*
echo $name;
echo $mailto;
echo $msg;
echo $mailto;
echo $mailfrom;
echo $email_from;
echo $email_subject;*/


  if ( mail($mailto,$email_subject,$email_body,$headers,"-f$mailfrom") )
  {
      // mail('amit@aayaamlabs.com',$email_subject,$email_body,$headers,"-f$mailfrom")
  	echo "1";
  	return 1;
  }
  else{
  	echo "0";
  	return 0;
  }
          /* return(mail($mailto,$email_subject,$email_body,$headers,"-f$mailfrom"));*/




}

}