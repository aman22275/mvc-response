<?php

class Sensenuts extends CI_Controller{



public function  index(){

$this->load->view('sensenuts');
}
}