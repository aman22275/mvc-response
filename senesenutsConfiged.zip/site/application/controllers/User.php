<?php

class User extends CI_Controller{

function __construct(){
	parent::__construct();
	$this->load->model('usermodel');
}

public function  index(){

redirect( site_url() );

}

private function auth_session(){

	if($this->session->userdata('id') ){
		return true;
		//logged in, show profile page
		//redirect( site_url('profile') );
	}else{
	    return false;
	}


}

public function login(){
	
	if($this->auth_session() ){

			echo json_encode(
					array(
						'status' => true,
						'message' => 'Already logged in'
						)

				);
return true;
	}


	$data = $this->input->post();

	if($data){
		//means user if trying to log in

		$response = $this->usermodel->login($data);

		if($response){
			//do login
			$this->session->set_userdata('id' , $response[0]['id']);
			//redirect( site_url('profile') );
			echo json_encode(
					array(
						'status' => true,
						'message' => site_url('profile')
						)

				);

		}else{
			//do NOT login
			//$this->session->set_flashdata('message' , 'Invalid Credentials');
			//redirect( site_url('user/login') );
			echo json_encode(
					array(
						'status' => false,
						'message' => 'Wrong'
						)

				);

		}

		return TRUE;
	}

	$this->load->view('login');

}

public function logout(){
	$this->session->unset_userdata('id');
	$this->session->sess_destroy();
	redirect( site_url() );
}

}