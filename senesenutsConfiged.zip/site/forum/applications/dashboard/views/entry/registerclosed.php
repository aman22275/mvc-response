<?php if (!defined('APPLICATION')) exit(); ?>
<div class="FormTitleWrapper">
    <h1><?php echo t('Register for Membership'); ?></h1>

    <div class="FormWrapper">
        <div class="P"><?php echo t('Registration is currently closed.'); ?></div>
    </div>
</div>
