<?php if (!defined('APPLICATION')) exit(); ?>

<div class="SplashInfo">
    <h1><?php echo t('Deleted'); ?></h1>

    <p><?php echo t('The content you were looking for has been deleted.'); ?></p>
</div>
